namespace ErikaOS_v2_5
{
    partial class ErikaOSTask
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl_Tasks = new System.Windows.Forms.TabControl();
            this.tabPage_Task1 = new System.Windows.Forms.TabPage();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.checkedListBox_Task1_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task1 = new System.Windows.Forms.CheckedListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_Task1Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task1Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task1Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task1Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task1StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task1Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task1Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task2 = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.checkedListBox_Task2_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task2 = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox_Task2Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task2Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task2Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task2Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task2StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task2Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task2Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task3 = new System.Windows.Forms.TabPage();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.checkedListBox_Task3_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task3 = new System.Windows.Forms.CheckedListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox_Task3Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task3Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task3Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task3Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task3StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task3Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task3Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task4 = new System.Windows.Forms.TabPage();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.checkedListBox_Task4_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task4 = new System.Windows.Forms.CheckedListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox_Task4Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task4Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task4Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task4Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task4StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task4Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task4Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task5 = new System.Windows.Forms.TabPage();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.checkedListBox_Task5_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task5 = new System.Windows.Forms.CheckedListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.comboBox_Task5Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task5Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task5Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task5Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task5StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task5Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task5Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task6 = new System.Windows.Forms.TabPage();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.checkedListBox_Task6_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task6 = new System.Windows.Forms.CheckedListBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBox_Task6Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task6Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task6Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task6Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task6StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task6Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task6Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task7 = new System.Windows.Forms.TabPage();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.checkedListBox_Task7_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task7 = new System.Windows.Forms.CheckedListBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.comboBox_Task7Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task7Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task7Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task7Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task7StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task7Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task7Auto = new System.Windows.Forms.CheckBox();
            this.tabPage_Task8 = new System.Windows.Forms.TabPage();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.checkedListBox_Task8_Resource = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_Task8 = new System.Windows.Forms.CheckedListBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBox_Task8Schedule = new System.Windows.Forms.ComboBox();
            this.comboBox_Task8Priority = new System.Windows.Forms.ComboBox();
            this.textBox_Task8Name = new System.Windows.Forms.TextBox();
            this.numericUpDown_Task8Activation = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Task8StackSize = new System.Windows.Forms.NumericUpDown();
            this.checkBox_Task8Stack = new System.Windows.Forms.CheckBox();
            this.checkBox_Task8Auto = new System.Windows.Forms.CheckBox();
            this.button_AddTask = new System.Windows.Forms.Button();
            this.button_RemoveTask = new System.Windows.Forms.Button();
            this.tabControl_Tasks.SuspendLayout();
            this.tabPage_Task1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task1Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task1StackSize)).BeginInit();
            this.tabPage_Task2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task2Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task2StackSize)).BeginInit();
            this.tabPage_Task3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task3Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task3StackSize)).BeginInit();
            this.tabPage_Task4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task4Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task4StackSize)).BeginInit();
            this.tabPage_Task5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task5Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task5StackSize)).BeginInit();
            this.tabPage_Task6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task6Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task6StackSize)).BeginInit();
            this.tabPage_Task7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task7Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task7StackSize)).BeginInit();
            this.tabPage_Task8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task8Activation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task8StackSize)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl_Tasks
            // 
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task1);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task2);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task3);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task4);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task5);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task6);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task7);
            this.tabControl_Tasks.Controls.Add(this.tabPage_Task8);
            this.tabControl_Tasks.Location = new System.Drawing.Point(3, 3);
            this.tabControl_Tasks.Name = "tabControl_Tasks";
            this.tabControl_Tasks.SelectedIndex = 0;
            this.tabControl_Tasks.Size = new System.Drawing.Size(448, 213);
            this.tabControl_Tasks.TabIndex = 0;
            // 
            // tabPage_Task1
            // 
            this.tabPage_Task1.Controls.Add(this.label42);
            this.tabPage_Task1.Controls.Add(this.label41);
            this.tabPage_Task1.Controls.Add(this.checkedListBox_Task1_Resource);
            this.tabPage_Task1.Controls.Add(this.checkedListBox_Task1);
            this.tabPage_Task1.Controls.Add(this.label5);
            this.tabPage_Task1.Controls.Add(this.label4);
            this.tabPage_Task1.Controls.Add(this.label3);
            this.tabPage_Task1.Controls.Add(this.label2);
            this.tabPage_Task1.Controls.Add(this.label1);
            this.tabPage_Task1.Controls.Add(this.comboBox_Task1Schedule);
            this.tabPage_Task1.Controls.Add(this.comboBox_Task1Priority);
            this.tabPage_Task1.Controls.Add(this.textBox_Task1Name);
            this.tabPage_Task1.Controls.Add(this.numericUpDown_Task1Activation);
            this.tabPage_Task1.Controls.Add(this.numericUpDown_Task1StackSize);
            this.tabPage_Task1.Controls.Add(this.checkBox_Task1Stack);
            this.tabPage_Task1.Controls.Add(this.checkBox_Task1Auto);
            this.tabPage_Task1.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task1.Name = "tabPage_Task1";
            this.tabPage_Task1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Task1.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task1.TabIndex = 0;
            this.tabPage_Task1.Text = "Task_1";
            this.tabPage_Task1.UseVisualStyleBackColor = true;
            this.tabPage_Task1.Click += new System.EventHandler(this.tabPage_Task1_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(274, 41);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(72, 13);
            this.label42.TabIndex = 15;
            this.label42.Text = "Resource List";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(147, 41);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(54, 13);
            this.label41.TabIndex = 14;
            this.label41.Text = "Event List";
            // 
            // checkedListBox_Task1_Resource
            // 
            this.checkedListBox_Task1_Resource.FormattingEnabled = true;
            this.checkedListBox_Task1_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task1_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task1_Resource.Name = "checkedListBox_Task1_Resource";
            this.checkedListBox_Task1_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task1_Resource.TabIndex = 13;
            this.checkedListBox_Task1_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task1_Resource_ItemCheck);
            // 
            // checkedListBox_Task1
            // 
            this.checkedListBox_Task1.FormattingEnabled = true;
            this.checkedListBox_Task1.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task1.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task1.Name = "checkedListBox_Task1";
            this.checkedListBox_Task1.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task1.TabIndex = 12;
            this.checkedListBox_Task1.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task1_ItemCheck);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Task Schedule";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(147, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Task Priority";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Task Activation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Stack Size";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Task Name";
            // 
            // comboBox_Task1Schedule
            // 
            this.comboBox_Task1Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task1Schedule.FormattingEnabled = true;
            this.comboBox_Task1Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task1Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task1Schedule.Name = "comboBox_Task1Schedule";
            this.comboBox_Task1Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task1Schedule.TabIndex = 6;
            this.comboBox_Task1Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task1Schedule_SelectedIndexChanged);
            this.comboBox_Task1Schedule.MouseHover += new System.EventHandler(this.comboBox_Task1Schedule_MouseHover);
            // 
            // comboBox_Task1Priority
            // 
            this.comboBox_Task1Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task1Priority.FormattingEnabled = true;
            this.comboBox_Task1Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task1Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task1Priority.Name = "comboBox_Task1Priority";
            this.comboBox_Task1Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task1Priority.TabIndex = 5;
            this.comboBox_Task1Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox_Task1Priority.MouseHover += new System.EventHandler(this.comboBox_Task1Priority_MouseHover);
            // 
            // textBox_Task1Name
            // 
            this.textBox_Task1Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task1Name.Name = "textBox_Task1Name";
            this.textBox_Task1Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task1Name.TabIndex = 4;
            this.textBox_Task1Name.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // numericUpDown_Task1Activation
            // 
            this.numericUpDown_Task1Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task1Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task1Activation.Name = "numericUpDown_Task1Activation";
            this.numericUpDown_Task1Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task1Activation.TabIndex = 3;
            this.numericUpDown_Task1Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task1Activation_ValueChanged);
            // 
            // numericUpDown_Task1StackSize
            // 
            this.numericUpDown_Task1StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task1StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task1StackSize.Name = "numericUpDown_Task1StackSize";
            this.numericUpDown_Task1StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task1StackSize.TabIndex = 2;
            this.numericUpDown_Task1StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task1StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task1StackSize_ValueChanged);
            // 
            // checkBox_Task1Stack
            // 
            this.checkBox_Task1Stack.AutoSize = true;
            this.checkBox_Task1Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task1Stack.Name = "checkBox_Task1Stack";
            this.checkBox_Task1Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task1Stack.TabIndex = 1;
            this.checkBox_Task1Stack.Text = "Private Stack";
            this.checkBox_Task1Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task1Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task1Stack_CheckedChanged);
            // 
            // checkBox_Task1Auto
            // 
            this.checkBox_Task1Auto.AutoSize = true;
            this.checkBox_Task1Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task1Auto.Name = "checkBox_Task1Auto";
            this.checkBox_Task1Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task1Auto.TabIndex = 0;
            this.checkBox_Task1Auto.Text = "Autostart";
            this.checkBox_Task1Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task1Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task1Auto_CheckedChanged);
            // 
            // tabPage_Task2
            // 
            this.tabPage_Task2.Controls.Add(this.label43);
            this.tabPage_Task2.Controls.Add(this.label44);
            this.tabPage_Task2.Controls.Add(this.checkedListBox_Task2_Resource);
            this.tabPage_Task2.Controls.Add(this.checkedListBox_Task2);
            this.tabPage_Task2.Controls.Add(this.label6);
            this.tabPage_Task2.Controls.Add(this.label7);
            this.tabPage_Task2.Controls.Add(this.label8);
            this.tabPage_Task2.Controls.Add(this.label9);
            this.tabPage_Task2.Controls.Add(this.label10);
            this.tabPage_Task2.Controls.Add(this.comboBox_Task2Schedule);
            this.tabPage_Task2.Controls.Add(this.comboBox_Task2Priority);
            this.tabPage_Task2.Controls.Add(this.textBox_Task2Name);
            this.tabPage_Task2.Controls.Add(this.numericUpDown_Task2Activation);
            this.tabPage_Task2.Controls.Add(this.numericUpDown_Task2StackSize);
            this.tabPage_Task2.Controls.Add(this.checkBox_Task2Stack);
            this.tabPage_Task2.Controls.Add(this.checkBox_Task2Auto);
            this.tabPage_Task2.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task2.Name = "tabPage_Task2";
            this.tabPage_Task2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Task2.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task2.TabIndex = 1;
            this.tabPage_Task2.Text = "Task_2";
            this.tabPage_Task2.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(274, 41);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(72, 13);
            this.label43.TabIndex = 27;
            this.label43.Text = "Resource List";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(147, 41);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 13);
            this.label44.TabIndex = 26;
            this.label44.Text = "Event List";
            // 
            // checkedListBox_Task2_Resource
            // 
            this.checkedListBox_Task2_Resource.FormattingEnabled = true;
            this.checkedListBox_Task2_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task2_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task2_Resource.Name = "checkedListBox_Task2_Resource";
            this.checkedListBox_Task2_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task2_Resource.TabIndex = 25;
            this.checkedListBox_Task2_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task2_Resource_ItemCheck);
            // 
            // checkedListBox_Task2
            // 
            this.checkedListBox_Task2.FormattingEnabled = true;
            this.checkedListBox_Task2.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task2.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task2.Name = "checkedListBox_Task2";
            this.checkedListBox_Task2.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task2.TabIndex = 24;
            this.checkedListBox_Task2.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task2_ItemCheck);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Task Schedule";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(147, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Task Priority";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Task Activation";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Stack Size";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Task Name";
            // 
            // comboBox_Task2Schedule
            // 
            this.comboBox_Task2Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task2Schedule.FormattingEnabled = true;
            this.comboBox_Task2Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task2Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task2Schedule.Name = "comboBox_Task2Schedule";
            this.comboBox_Task2Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task2Schedule.TabIndex = 18;
            this.comboBox_Task2Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task2Schedule_SelectedIndexChanged);
            this.comboBox_Task2Schedule.MouseHover += new System.EventHandler(this.comboBox_Task2Schedule_MouseHover);
            // 
            // comboBox_Task2Priority
            // 
            this.comboBox_Task2Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task2Priority.FormattingEnabled = true;
            this.comboBox_Task2Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task2Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task2Priority.Name = "comboBox_Task2Priority";
            this.comboBox_Task2Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task2Priority.TabIndex = 17;
            this.comboBox_Task2Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task2Priority_SelectedIndexChanged);
            this.comboBox_Task2Priority.MouseHover += new System.EventHandler(this.comboBox_Task2Priority_MouseHover);
            // 
            // textBox_Task2Name
            // 
            this.textBox_Task2Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task2Name.Name = "textBox_Task2Name";
            this.textBox_Task2Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task2Name.TabIndex = 16;
            this.textBox_Task2Name.TextChanged += new System.EventHandler(this.textBox_Task2Name_TextChanged);
            // 
            // numericUpDown_Task2Activation
            // 
            this.numericUpDown_Task2Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task2Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task2Activation.Name = "numericUpDown_Task2Activation";
            this.numericUpDown_Task2Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task2Activation.TabIndex = 15;
            this.numericUpDown_Task2Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task2Activation_ValueChanged);
            // 
            // numericUpDown_Task2StackSize
            // 
            this.numericUpDown_Task2StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task2StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task2StackSize.Name = "numericUpDown_Task2StackSize";
            this.numericUpDown_Task2StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task2StackSize.TabIndex = 14;
            this.numericUpDown_Task2StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task2StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task2StackSize_ValueChanged);
            // 
            // checkBox_Task2Stack
            // 
            this.checkBox_Task2Stack.AutoSize = true;
            this.checkBox_Task2Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task2Stack.Name = "checkBox_Task2Stack";
            this.checkBox_Task2Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task2Stack.TabIndex = 13;
            this.checkBox_Task2Stack.Text = "Private Stack";
            this.checkBox_Task2Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task2Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task2Stack_CheckedChanged);
            // 
            // checkBox_Task2Auto
            // 
            this.checkBox_Task2Auto.AutoSize = true;
            this.checkBox_Task2Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task2Auto.Name = "checkBox_Task2Auto";
            this.checkBox_Task2Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task2Auto.TabIndex = 12;
            this.checkBox_Task2Auto.Text = "Autostart";
            this.checkBox_Task2Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task2Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task2Auto_CheckedChanged);
            // 
            // tabPage_Task3
            // 
            this.tabPage_Task3.Controls.Add(this.label45);
            this.tabPage_Task3.Controls.Add(this.label46);
            this.tabPage_Task3.Controls.Add(this.checkedListBox_Task3_Resource);
            this.tabPage_Task3.Controls.Add(this.checkedListBox_Task3);
            this.tabPage_Task3.Controls.Add(this.label11);
            this.tabPage_Task3.Controls.Add(this.label12);
            this.tabPage_Task3.Controls.Add(this.label13);
            this.tabPage_Task3.Controls.Add(this.label14);
            this.tabPage_Task3.Controls.Add(this.label15);
            this.tabPage_Task3.Controls.Add(this.comboBox_Task3Schedule);
            this.tabPage_Task3.Controls.Add(this.comboBox_Task3Priority);
            this.tabPage_Task3.Controls.Add(this.textBox_Task3Name);
            this.tabPage_Task3.Controls.Add(this.numericUpDown_Task3Activation);
            this.tabPage_Task3.Controls.Add(this.numericUpDown_Task3StackSize);
            this.tabPage_Task3.Controls.Add(this.checkBox_Task3Stack);
            this.tabPage_Task3.Controls.Add(this.checkBox_Task3Auto);
            this.tabPage_Task3.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task3.Name = "tabPage_Task3";
            this.tabPage_Task3.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task3.TabIndex = 2;
            this.tabPage_Task3.Text = "Task_3";
            this.tabPage_Task3.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(274, 41);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(72, 13);
            this.label45.TabIndex = 27;
            this.label45.Text = "Resource List";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(147, 41);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(54, 13);
            this.label46.TabIndex = 26;
            this.label46.Text = "Event List";
            // 
            // checkedListBox_Task3_Resource
            // 
            this.checkedListBox_Task3_Resource.FormattingEnabled = true;
            this.checkedListBox_Task3_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task3_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task3_Resource.Name = "checkedListBox_Task3_Resource";
            this.checkedListBox_Task3_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task3_Resource.TabIndex = 25;
            this.checkedListBox_Task3_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task3_Resource_ItemCheck);
            // 
            // checkedListBox_Task3
            // 
            this.checkedListBox_Task3.FormattingEnabled = true;
            this.checkedListBox_Task3.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task3.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task3.Name = "checkedListBox_Task3";
            this.checkedListBox_Task3.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task3.TabIndex = 24;
            this.checkedListBox_Task3.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task3_ItemCheck);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(274, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Task Schedule";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(147, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Task Priority";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "Task Activation";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 13);
            this.label14.TabIndex = 20;
            this.label14.Text = "Stack Size";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 2);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 19;
            this.label15.Text = "Task Name";
            // 
            // comboBox_Task3Schedule
            // 
            this.comboBox_Task3Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task3Schedule.FormattingEnabled = true;
            this.comboBox_Task3Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task3Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task3Schedule.Name = "comboBox_Task3Schedule";
            this.comboBox_Task3Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task3Schedule.TabIndex = 18;
            this.comboBox_Task3Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task3Schedule_SelectedIndexChanged);
            this.comboBox_Task3Schedule.MouseHover += new System.EventHandler(this.comboBox_Task3Schedule_MouseHover);
            // 
            // comboBox_Task3Priority
            // 
            this.comboBox_Task3Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task3Priority.FormattingEnabled = true;
            this.comboBox_Task3Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task3Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task3Priority.Name = "comboBox_Task3Priority";
            this.comboBox_Task3Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task3Priority.TabIndex = 17;
            this.comboBox_Task3Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task3Priority_SelectedIndexChanged);
            this.comboBox_Task3Priority.MouseHover += new System.EventHandler(this.comboBox_Task3Priority_MouseHover);
            // 
            // textBox_Task3Name
            // 
            this.textBox_Task3Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task3Name.Name = "textBox_Task3Name";
            this.textBox_Task3Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task3Name.TabIndex = 16;
            this.textBox_Task3Name.TextChanged += new System.EventHandler(this.textBox_Task3Name_TextChanged);
            // 
            // numericUpDown_Task3Activation
            // 
            this.numericUpDown_Task3Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task3Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task3Activation.Name = "numericUpDown_Task3Activation";
            this.numericUpDown_Task3Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task3Activation.TabIndex = 15;
            this.numericUpDown_Task3Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task3Activation_ValueChanged);
            // 
            // numericUpDown_Task3StackSize
            // 
            this.numericUpDown_Task3StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task3StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task3StackSize.Name = "numericUpDown_Task3StackSize";
            this.numericUpDown_Task3StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task3StackSize.TabIndex = 14;
            this.numericUpDown_Task3StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task3StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task3StackSize_ValueChanged);
            // 
            // checkBox_Task3Stack
            // 
            this.checkBox_Task3Stack.AutoSize = true;
            this.checkBox_Task3Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task3Stack.Name = "checkBox_Task3Stack";
            this.checkBox_Task3Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task3Stack.TabIndex = 13;
            this.checkBox_Task3Stack.Text = "Private Stack";
            this.checkBox_Task3Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task3Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task3Stack_CheckedChanged);
            // 
            // checkBox_Task3Auto
            // 
            this.checkBox_Task3Auto.AutoSize = true;
            this.checkBox_Task3Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task3Auto.Name = "checkBox_Task3Auto";
            this.checkBox_Task3Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task3Auto.TabIndex = 12;
            this.checkBox_Task3Auto.Text = "Autostart";
            this.checkBox_Task3Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task3Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task3Auto_CheckedChanged);
            // 
            // tabPage_Task4
            // 
            this.tabPage_Task4.Controls.Add(this.label47);
            this.tabPage_Task4.Controls.Add(this.label48);
            this.tabPage_Task4.Controls.Add(this.checkedListBox_Task4_Resource);
            this.tabPage_Task4.Controls.Add(this.checkedListBox_Task4);
            this.tabPage_Task4.Controls.Add(this.label16);
            this.tabPage_Task4.Controls.Add(this.label17);
            this.tabPage_Task4.Controls.Add(this.label18);
            this.tabPage_Task4.Controls.Add(this.label19);
            this.tabPage_Task4.Controls.Add(this.label20);
            this.tabPage_Task4.Controls.Add(this.comboBox_Task4Schedule);
            this.tabPage_Task4.Controls.Add(this.comboBox_Task4Priority);
            this.tabPage_Task4.Controls.Add(this.textBox_Task4Name);
            this.tabPage_Task4.Controls.Add(this.numericUpDown_Task4Activation);
            this.tabPage_Task4.Controls.Add(this.numericUpDown_Task4StackSize);
            this.tabPage_Task4.Controls.Add(this.checkBox_Task4Stack);
            this.tabPage_Task4.Controls.Add(this.checkBox_Task4Auto);
            this.tabPage_Task4.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task4.Name = "tabPage_Task4";
            this.tabPage_Task4.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task4.TabIndex = 3;
            this.tabPage_Task4.Text = "Task_4";
            this.tabPage_Task4.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(274, 41);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(72, 13);
            this.label47.TabIndex = 27;
            this.label47.Text = "Resource List";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(147, 41);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(54, 13);
            this.label48.TabIndex = 26;
            this.label48.Text = "Event List";
            // 
            // checkedListBox_Task4_Resource
            // 
            this.checkedListBox_Task4_Resource.FormattingEnabled = true;
            this.checkedListBox_Task4_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task4_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task4_Resource.Name = "checkedListBox_Task4_Resource";
            this.checkedListBox_Task4_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task4_Resource.TabIndex = 25;
            this.checkedListBox_Task4_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task4_Resource_ItemCheck);
            // 
            // checkedListBox_Task4
            // 
            this.checkedListBox_Task4.FormattingEnabled = true;
            this.checkedListBox_Task4.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task4.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task4.Name = "checkedListBox_Task4";
            this.checkedListBox_Task4.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task4.TabIndex = 24;
            this.checkedListBox_Task4.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task4_ItemCheck);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(274, 1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 23;
            this.label16.Text = "Task Schedule";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(147, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Task Priority";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 126);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "Task Activation";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 87);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "Stack Size";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 2);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 13);
            this.label20.TabIndex = 19;
            this.label20.Text = "Task Name";
            // 
            // comboBox_Task4Schedule
            // 
            this.comboBox_Task4Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task4Schedule.FormattingEnabled = true;
            this.comboBox_Task4Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task4Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task4Schedule.Name = "comboBox_Task4Schedule";
            this.comboBox_Task4Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task4Schedule.TabIndex = 18;
            this.comboBox_Task4Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task4Schedule_SelectedIndexChanged);
            this.comboBox_Task4Schedule.MouseHover += new System.EventHandler(this.comboBox_Task4Schedule_MouseHover);
            // 
            // comboBox_Task4Priority
            // 
            this.comboBox_Task4Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task4Priority.FormattingEnabled = true;
            this.comboBox_Task4Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task4Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task4Priority.Name = "comboBox_Task4Priority";
            this.comboBox_Task4Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task4Priority.TabIndex = 17;
            this.comboBox_Task4Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task4Priority_SelectedIndexChanged);
            this.comboBox_Task4Priority.MouseHover += new System.EventHandler(this.comboBox_Task4Priority_MouseHover);
            // 
            // textBox_Task4Name
            // 
            this.textBox_Task4Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task4Name.Name = "textBox_Task4Name";
            this.textBox_Task4Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task4Name.TabIndex = 16;
            this.textBox_Task4Name.TextChanged += new System.EventHandler(this.textBox_Task4Name_TextChanged);
            // 
            // numericUpDown_Task4Activation
            // 
            this.numericUpDown_Task4Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task4Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task4Activation.Name = "numericUpDown_Task4Activation";
            this.numericUpDown_Task4Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task4Activation.TabIndex = 15;
            this.numericUpDown_Task4Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task4Activation_ValueChanged);
            // 
            // numericUpDown_Task4StackSize
            // 
            this.numericUpDown_Task4StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task4StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task4StackSize.Name = "numericUpDown_Task4StackSize";
            this.numericUpDown_Task4StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task4StackSize.TabIndex = 14;
            this.numericUpDown_Task4StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task4StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task4StackSize_ValueChanged);
            // 
            // checkBox_Task4Stack
            // 
            this.checkBox_Task4Stack.AutoSize = true;
            this.checkBox_Task4Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task4Stack.Name = "checkBox_Task4Stack";
            this.checkBox_Task4Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task4Stack.TabIndex = 13;
            this.checkBox_Task4Stack.Text = "Private Stack";
            this.checkBox_Task4Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task4Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task4Stack_CheckedChanged);
            // 
            // checkBox_Task4Auto
            // 
            this.checkBox_Task4Auto.AutoSize = true;
            this.checkBox_Task4Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task4Auto.Name = "checkBox_Task4Auto";
            this.checkBox_Task4Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task4Auto.TabIndex = 12;
            this.checkBox_Task4Auto.Text = "Autostart";
            this.checkBox_Task4Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task4Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task4Auto_CheckedChanged);
            // 
            // tabPage_Task5
            // 
            this.tabPage_Task5.Controls.Add(this.label49);
            this.tabPage_Task5.Controls.Add(this.label50);
            this.tabPage_Task5.Controls.Add(this.checkedListBox_Task5_Resource);
            this.tabPage_Task5.Controls.Add(this.checkedListBox_Task5);
            this.tabPage_Task5.Controls.Add(this.label21);
            this.tabPage_Task5.Controls.Add(this.label22);
            this.tabPage_Task5.Controls.Add(this.label23);
            this.tabPage_Task5.Controls.Add(this.label24);
            this.tabPage_Task5.Controls.Add(this.label25);
            this.tabPage_Task5.Controls.Add(this.comboBox_Task5Schedule);
            this.tabPage_Task5.Controls.Add(this.comboBox_Task5Priority);
            this.tabPage_Task5.Controls.Add(this.textBox_Task5Name);
            this.tabPage_Task5.Controls.Add(this.numericUpDown_Task5Activation);
            this.tabPage_Task5.Controls.Add(this.numericUpDown_Task5StackSize);
            this.tabPage_Task5.Controls.Add(this.checkBox_Task5Stack);
            this.tabPage_Task5.Controls.Add(this.checkBox_Task5Auto);
            this.tabPage_Task5.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task5.Name = "tabPage_Task5";
            this.tabPage_Task5.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task5.TabIndex = 4;
            this.tabPage_Task5.Text = "Task_5";
            this.tabPage_Task5.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(274, 41);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(72, 13);
            this.label49.TabIndex = 27;
            this.label49.Text = "Resource List";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(147, 41);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(54, 13);
            this.label50.TabIndex = 26;
            this.label50.Text = "Event List";
            // 
            // checkedListBox_Task5_Resource
            // 
            this.checkedListBox_Task5_Resource.FormattingEnabled = true;
            this.checkedListBox_Task5_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task5_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task5_Resource.Name = "checkedListBox_Task5_Resource";
            this.checkedListBox_Task5_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task5_Resource.TabIndex = 25;
            this.checkedListBox_Task5_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task5_Resource_ItemCheck);
            // 
            // checkedListBox_Task5
            // 
            this.checkedListBox_Task5.FormattingEnabled = true;
            this.checkedListBox_Task5.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task5.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task5.Name = "checkedListBox_Task5";
            this.checkedListBox_Task5.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task5.TabIndex = 24;
            this.checkedListBox_Task5.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task5_ItemCheck);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(274, 1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 23;
            this.label21.Text = "Task Schedule";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(147, 2);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Task Priority";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 126);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 13);
            this.label23.TabIndex = 21;
            this.label23.Text = "Task Activation";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 87);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 13);
            this.label24.TabIndex = 20;
            this.label24.Text = "Stack Size";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 13);
            this.label25.TabIndex = 19;
            this.label25.Text = "Task Name";
            // 
            // comboBox_Task5Schedule
            // 
            this.comboBox_Task5Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task5Schedule.FormattingEnabled = true;
            this.comboBox_Task5Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task5Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task5Schedule.Name = "comboBox_Task5Schedule";
            this.comboBox_Task5Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task5Schedule.TabIndex = 18;
            this.comboBox_Task5Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task5Schedule_SelectedIndexChanged);
            this.comboBox_Task5Schedule.MouseHover += new System.EventHandler(this.comboBox_Task5Schedule_MouseHover);
            // 
            // comboBox_Task5Priority
            // 
            this.comboBox_Task5Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task5Priority.FormattingEnabled = true;
            this.comboBox_Task5Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task5Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task5Priority.Name = "comboBox_Task5Priority";
            this.comboBox_Task5Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task5Priority.TabIndex = 17;
            this.comboBox_Task5Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task5Priority_SelectedIndexChanged);
            this.comboBox_Task5Priority.MouseHover += new System.EventHandler(this.comboBox_Task5Priority_MouseHover);
            // 
            // textBox_Task5Name
            // 
            this.textBox_Task5Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task5Name.Name = "textBox_Task5Name";
            this.textBox_Task5Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task5Name.TabIndex = 16;
            this.textBox_Task5Name.TextChanged += new System.EventHandler(this.textBox_Task5Name_TextChanged);
            // 
            // numericUpDown_Task5Activation
            // 
            this.numericUpDown_Task5Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task5Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task5Activation.Name = "numericUpDown_Task5Activation";
            this.numericUpDown_Task5Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task5Activation.TabIndex = 15;
            this.numericUpDown_Task5Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task5Activation_ValueChanged);
            // 
            // numericUpDown_Task5StackSize
            // 
            this.numericUpDown_Task5StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task5StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task5StackSize.Name = "numericUpDown_Task5StackSize";
            this.numericUpDown_Task5StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task5StackSize.TabIndex = 14;
            this.numericUpDown_Task5StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task5StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task5StackSize_ValueChanged);
            // 
            // checkBox_Task5Stack
            // 
            this.checkBox_Task5Stack.AutoSize = true;
            this.checkBox_Task5Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task5Stack.Name = "checkBox_Task5Stack";
            this.checkBox_Task5Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task5Stack.TabIndex = 13;
            this.checkBox_Task5Stack.Text = "Private Stack";
            this.checkBox_Task5Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task5Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task5Stack_CheckedChanged);
            // 
            // checkBox_Task5Auto
            // 
            this.checkBox_Task5Auto.AutoSize = true;
            this.checkBox_Task5Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task5Auto.Name = "checkBox_Task5Auto";
            this.checkBox_Task5Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task5Auto.TabIndex = 12;
            this.checkBox_Task5Auto.Text = "Autostart";
            this.checkBox_Task5Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task5Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task5Auto_CheckedChanged);
            // 
            // tabPage_Task6
            // 
            this.tabPage_Task6.Controls.Add(this.label51);
            this.tabPage_Task6.Controls.Add(this.label52);
            this.tabPage_Task6.Controls.Add(this.checkedListBox_Task6_Resource);
            this.tabPage_Task6.Controls.Add(this.checkedListBox_Task6);
            this.tabPage_Task6.Controls.Add(this.label26);
            this.tabPage_Task6.Controls.Add(this.label27);
            this.tabPage_Task6.Controls.Add(this.label28);
            this.tabPage_Task6.Controls.Add(this.label29);
            this.tabPage_Task6.Controls.Add(this.label30);
            this.tabPage_Task6.Controls.Add(this.comboBox_Task6Schedule);
            this.tabPage_Task6.Controls.Add(this.comboBox_Task6Priority);
            this.tabPage_Task6.Controls.Add(this.textBox_Task6Name);
            this.tabPage_Task6.Controls.Add(this.numericUpDown_Task6Activation);
            this.tabPage_Task6.Controls.Add(this.numericUpDown_Task6StackSize);
            this.tabPage_Task6.Controls.Add(this.checkBox_Task6Stack);
            this.tabPage_Task6.Controls.Add(this.checkBox_Task6Auto);
            this.tabPage_Task6.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task6.Name = "tabPage_Task6";
            this.tabPage_Task6.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task6.TabIndex = 5;
            this.tabPage_Task6.Text = "Task_6";
            this.tabPage_Task6.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(274, 41);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(72, 13);
            this.label51.TabIndex = 27;
            this.label51.Text = "Resource List";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(147, 41);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(54, 13);
            this.label52.TabIndex = 26;
            this.label52.Text = "Event List";
            // 
            // checkedListBox_Task6_Resource
            // 
            this.checkedListBox_Task6_Resource.FormattingEnabled = true;
            this.checkedListBox_Task6_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task6_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task6_Resource.Name = "checkedListBox_Task6_Resource";
            this.checkedListBox_Task6_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task6_Resource.TabIndex = 25;
            this.checkedListBox_Task6_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task6_Resource_ItemCheck);
            // 
            // checkedListBox_Task6
            // 
            this.checkedListBox_Task6.FormattingEnabled = true;
            this.checkedListBox_Task6.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task6.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task6.Name = "checkedListBox_Task6";
            this.checkedListBox_Task6.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task6.TabIndex = 24;
            this.checkedListBox_Task6.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task6_ItemCheck);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(274, 1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 13);
            this.label26.TabIndex = 23;
            this.label26.Text = "Task Schedule";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(147, 2);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Task Priority";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 126);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(81, 13);
            this.label28.TabIndex = 21;
            this.label28.Text = "Task Activation";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 87);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 13);
            this.label29.TabIndex = 20;
            this.label29.Text = "Stack Size";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 2);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(62, 13);
            this.label30.TabIndex = 19;
            this.label30.Text = "Task Name";
            // 
            // comboBox_Task6Schedule
            // 
            this.comboBox_Task6Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task6Schedule.FormattingEnabled = true;
            this.comboBox_Task6Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task6Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task6Schedule.Name = "comboBox_Task6Schedule";
            this.comboBox_Task6Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task6Schedule.TabIndex = 18;
            this.comboBox_Task6Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task6Schedule_SelectedIndexChanged);
            this.comboBox_Task6Schedule.MouseHover += new System.EventHandler(this.comboBox_Task6Schedule_MouseHover);
            // 
            // comboBox_Task6Priority
            // 
            this.comboBox_Task6Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task6Priority.FormattingEnabled = true;
            this.comboBox_Task6Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task6Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task6Priority.Name = "comboBox_Task6Priority";
            this.comboBox_Task6Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task6Priority.TabIndex = 17;
            this.comboBox_Task6Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task6Priority_SelectedIndexChanged);
            this.comboBox_Task6Priority.MouseHover += new System.EventHandler(this.comboBox_Task6Priority_MouseHover);
            // 
            // textBox_Task6Name
            // 
            this.textBox_Task6Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task6Name.Name = "textBox_Task6Name";
            this.textBox_Task6Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task6Name.TabIndex = 16;
            this.textBox_Task6Name.TextChanged += new System.EventHandler(this.textBox_Task6Name_TextChanged);
            // 
            // numericUpDown_Task6Activation
            // 
            this.numericUpDown_Task6Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task6Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task6Activation.Name = "numericUpDown_Task6Activation";
            this.numericUpDown_Task6Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task6Activation.TabIndex = 15;
            this.numericUpDown_Task6Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task6Activation_ValueChanged);
            // 
            // numericUpDown_Task6StackSize
            // 
            this.numericUpDown_Task6StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task6StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task6StackSize.Name = "numericUpDown_Task6StackSize";
            this.numericUpDown_Task6StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task6StackSize.TabIndex = 14;
            this.numericUpDown_Task6StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task6StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task6StackSize_ValueChanged);
            // 
            // checkBox_Task6Stack
            // 
            this.checkBox_Task6Stack.AutoSize = true;
            this.checkBox_Task6Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task6Stack.Name = "checkBox_Task6Stack";
            this.checkBox_Task6Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task6Stack.TabIndex = 13;
            this.checkBox_Task6Stack.Text = "Private Stack";
            this.checkBox_Task6Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task6Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task6Stack_CheckedChanged);
            // 
            // checkBox_Task6Auto
            // 
            this.checkBox_Task6Auto.AutoSize = true;
            this.checkBox_Task6Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task6Auto.Name = "checkBox_Task6Auto";
            this.checkBox_Task6Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task6Auto.TabIndex = 12;
            this.checkBox_Task6Auto.Text = "Autostart";
            this.checkBox_Task6Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task6Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task6Auto_CheckedChanged);
            // 
            // tabPage_Task7
            // 
            this.tabPage_Task7.Controls.Add(this.label53);
            this.tabPage_Task7.Controls.Add(this.label54);
            this.tabPage_Task7.Controls.Add(this.checkedListBox_Task7_Resource);
            this.tabPage_Task7.Controls.Add(this.checkedListBox_Task7);
            this.tabPage_Task7.Controls.Add(this.label31);
            this.tabPage_Task7.Controls.Add(this.label32);
            this.tabPage_Task7.Controls.Add(this.label33);
            this.tabPage_Task7.Controls.Add(this.label34);
            this.tabPage_Task7.Controls.Add(this.label35);
            this.tabPage_Task7.Controls.Add(this.comboBox_Task7Schedule);
            this.tabPage_Task7.Controls.Add(this.comboBox_Task7Priority);
            this.tabPage_Task7.Controls.Add(this.textBox_Task7Name);
            this.tabPage_Task7.Controls.Add(this.numericUpDown_Task7Activation);
            this.tabPage_Task7.Controls.Add(this.numericUpDown_Task7StackSize);
            this.tabPage_Task7.Controls.Add(this.checkBox_Task7Stack);
            this.tabPage_Task7.Controls.Add(this.checkBox_Task7Auto);
            this.tabPage_Task7.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task7.Name = "tabPage_Task7";
            this.tabPage_Task7.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task7.TabIndex = 6;
            this.tabPage_Task7.Text = "Task_7";
            this.tabPage_Task7.UseVisualStyleBackColor = true;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(274, 41);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(72, 13);
            this.label53.TabIndex = 27;
            this.label53.Text = "Resource List";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(147, 41);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(54, 13);
            this.label54.TabIndex = 26;
            this.label54.Text = "Event List";
            // 
            // checkedListBox_Task7_Resource
            // 
            this.checkedListBox_Task7_Resource.FormattingEnabled = true;
            this.checkedListBox_Task7_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task7_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task7_Resource.Name = "checkedListBox_Task7_Resource";
            this.checkedListBox_Task7_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task7_Resource.TabIndex = 25;
            this.checkedListBox_Task7_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task7_Resource_ItemCheck);
            // 
            // checkedListBox_Task7
            // 
            this.checkedListBox_Task7.FormattingEnabled = true;
            this.checkedListBox_Task7.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task7.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task7.Name = "checkedListBox_Task7";
            this.checkedListBox_Task7.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task7.TabIndex = 24;
            this.checkedListBox_Task7.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task7_ItemCheck);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(274, 1);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(79, 13);
            this.label31.TabIndex = 23;
            this.label31.Text = "Task Schedule";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(147, 2);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 13);
            this.label32.TabIndex = 22;
            this.label32.Text = "Task Priority";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(3, 126);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 13);
            this.label33.TabIndex = 21;
            this.label33.Text = "Task Activation";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(3, 87);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(58, 13);
            this.label34.TabIndex = 20;
            this.label34.Text = "Stack Size";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(3, 2);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 13);
            this.label35.TabIndex = 19;
            this.label35.Text = "Task Name";
            // 
            // comboBox_Task7Schedule
            // 
            this.comboBox_Task7Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task7Schedule.FormattingEnabled = true;
            this.comboBox_Task7Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task7Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task7Schedule.Name = "comboBox_Task7Schedule";
            this.comboBox_Task7Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task7Schedule.TabIndex = 18;
            this.comboBox_Task7Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task7Schedule_SelectedIndexChanged);
            this.comboBox_Task7Schedule.MouseHover += new System.EventHandler(this.comboBox_Task7Schedule_MouseHover);
            // 
            // comboBox_Task7Priority
            // 
            this.comboBox_Task7Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task7Priority.FormattingEnabled = true;
            this.comboBox_Task7Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task7Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task7Priority.Name = "comboBox_Task7Priority";
            this.comboBox_Task7Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task7Priority.TabIndex = 17;
            this.comboBox_Task7Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task7Priority_SelectedIndexChanged);
            this.comboBox_Task7Priority.MouseHover += new System.EventHandler(this.comboBox_Task7Priority_MouseHover);
            // 
            // textBox_Task7Name
            // 
            this.textBox_Task7Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task7Name.Name = "textBox_Task7Name";
            this.textBox_Task7Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task7Name.TabIndex = 16;
            this.textBox_Task7Name.TextChanged += new System.EventHandler(this.textBox_Task7Name_TextChanged);
            // 
            // numericUpDown_Task7Activation
            // 
            this.numericUpDown_Task7Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task7Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task7Activation.Name = "numericUpDown_Task7Activation";
            this.numericUpDown_Task7Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task7Activation.TabIndex = 15;
            this.numericUpDown_Task7Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task7Activation_ValueChanged);
            // 
            // numericUpDown_Task7StackSize
            // 
            this.numericUpDown_Task7StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task7StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task7StackSize.Name = "numericUpDown_Task7StackSize";
            this.numericUpDown_Task7StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task7StackSize.TabIndex = 14;
            this.numericUpDown_Task7StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task7StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task7StackSize_ValueChanged);
            // 
            // checkBox_Task7Stack
            // 
            this.checkBox_Task7Stack.AutoSize = true;
            this.checkBox_Task7Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task7Stack.Name = "checkBox_Task7Stack";
            this.checkBox_Task7Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task7Stack.TabIndex = 13;
            this.checkBox_Task7Stack.Text = "Private Stack";
            this.checkBox_Task7Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task7Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task7Stack_CheckedChanged);
            // 
            // checkBox_Task7Auto
            // 
            this.checkBox_Task7Auto.AutoSize = true;
            this.checkBox_Task7Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task7Auto.Name = "checkBox_Task7Auto";
            this.checkBox_Task7Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task7Auto.TabIndex = 12;
            this.checkBox_Task7Auto.Text = "Autostart";
            this.checkBox_Task7Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task7Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task7Auto_CheckedChanged);
            // 
            // tabPage_Task8
            // 
            this.tabPage_Task8.Controls.Add(this.label55);
            this.tabPage_Task8.Controls.Add(this.label56);
            this.tabPage_Task8.Controls.Add(this.checkedListBox_Task8_Resource);
            this.tabPage_Task8.Controls.Add(this.checkedListBox_Task8);
            this.tabPage_Task8.Controls.Add(this.label36);
            this.tabPage_Task8.Controls.Add(this.label37);
            this.tabPage_Task8.Controls.Add(this.label38);
            this.tabPage_Task8.Controls.Add(this.label39);
            this.tabPage_Task8.Controls.Add(this.label40);
            this.tabPage_Task8.Controls.Add(this.comboBox_Task8Schedule);
            this.tabPage_Task8.Controls.Add(this.comboBox_Task8Priority);
            this.tabPage_Task8.Controls.Add(this.textBox_Task8Name);
            this.tabPage_Task8.Controls.Add(this.numericUpDown_Task8Activation);
            this.tabPage_Task8.Controls.Add(this.numericUpDown_Task8StackSize);
            this.tabPage_Task8.Controls.Add(this.checkBox_Task8Stack);
            this.tabPage_Task8.Controls.Add(this.checkBox_Task8Auto);
            this.tabPage_Task8.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Task8.Name = "tabPage_Task8";
            this.tabPage_Task8.Size = new System.Drawing.Size(440, 187);
            this.tabPage_Task8.TabIndex = 7;
            this.tabPage_Task8.Text = "Task_8";
            this.tabPage_Task8.UseVisualStyleBackColor = true;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(274, 41);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(72, 13);
            this.label55.TabIndex = 27;
            this.label55.Text = "Resource List";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(147, 41);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(54, 13);
            this.label56.TabIndex = 26;
            this.label56.Text = "Event List";
            // 
            // checkedListBox_Task8_Resource
            // 
            this.checkedListBox_Task8_Resource.FormattingEnabled = true;
            this.checkedListBox_Task8_Resource.Items.AddRange(new object[] {
            "Resource_1",
            "Resource_2",
            "Resource_3",
            "Resource_4",
            "Resource_5",
            "Resource_6",
            "Resource_7",
            "Resource_8"});
            this.checkedListBox_Task8_Resource.Location = new System.Drawing.Point(276, 57);
            this.checkedListBox_Task8_Resource.Name = "checkedListBox_Task8_Resource";
            this.checkedListBox_Task8_Resource.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task8_Resource.TabIndex = 25;
            this.checkedListBox_Task8_Resource.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task8_Resource_ItemCheck);
            // 
            // checkedListBox_Task8
            // 
            this.checkedListBox_Task8.FormattingEnabled = true;
            this.checkedListBox_Task8.Items.AddRange(new object[] {
            "Event_1",
            "Event_2",
            "Event_3",
            "Event_4",
            "Event_5",
            "Event_6",
            "Event_7",
            "Event_8",
            "Event_9",
            "Event_10",
            "Event_11",
            "Event_12",
            "Event_13",
            "Event_14",
            "Event_15",
            "Event_16",
            "Event_17",
            "Event_18",
            "Event_19",
            "Event_20",
            "Event_21",
            "Event_22",
            "Event_23",
            "Event_24",
            "Event_25",
            "Event_26",
            "Event_27",
            "Event_28",
            "Event_29",
            "Event_30",
            "Event_31"});
            this.checkedListBox_Task8.Location = new System.Drawing.Point(150, 57);
            this.checkedListBox_Task8.Name = "checkedListBox_Task8";
            this.checkedListBox_Task8.Size = new System.Drawing.Size(120, 124);
            this.checkedListBox_Task8.TabIndex = 24;
            this.checkedListBox_Task8.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_Task8_ItemCheck);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(274, 1);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(79, 13);
            this.label36.TabIndex = 23;
            this.label36.Text = "Task Schedule";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(147, 2);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 13);
            this.label37.TabIndex = 22;
            this.label37.Text = "Task Priority";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(3, 126);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(81, 13);
            this.label38.TabIndex = 21;
            this.label38.Text = "Task Activation";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(3, 87);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 13);
            this.label39.TabIndex = 20;
            this.label39.Text = "Stack Size";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(3, 2);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(62, 13);
            this.label40.TabIndex = 19;
            this.label40.Text = "Task Name";
            // 
            // comboBox_Task8Schedule
            // 
            this.comboBox_Task8Schedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task8Schedule.FormattingEnabled = true;
            this.comboBox_Task8Schedule.Items.AddRange(new object[] {
            "Non",
            "Full"});
            this.comboBox_Task8Schedule.Location = new System.Drawing.Point(277, 17);
            this.comboBox_Task8Schedule.Name = "comboBox_Task8Schedule";
            this.comboBox_Task8Schedule.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task8Schedule.TabIndex = 18;
            this.comboBox_Task8Schedule.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task8Schedule_SelectedIndexChanged);
            this.comboBox_Task8Schedule.MouseHover += new System.EventHandler(this.comboBox_Task8Schedule_MouseHover);
            // 
            // comboBox_Task8Priority
            // 
            this.comboBox_Task8Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Task8Priority.FormattingEnabled = true;
            this.comboBox_Task8Priority.Items.AddRange(new object[] {
            "Choose Priority",
            "Priority 1",
            "Priority 2",
            "Priority 3",
            "Priority 4",
            "Priority 5",
            "Priority 6",
            "Priority 7",
            "Priority 8"});
            this.comboBox_Task8Priority.Location = new System.Drawing.Point(150, 17);
            this.comboBox_Task8Priority.Name = "comboBox_Task8Priority";
            this.comboBox_Task8Priority.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Task8Priority.TabIndex = 17;
            this.comboBox_Task8Priority.SelectedIndexChanged += new System.EventHandler(this.comboBox_Task8Priority_SelectedIndexChanged);
            this.comboBox_Task8Priority.MouseHover += new System.EventHandler(this.comboBox_Task8Priority_MouseHover);
            // 
            // textBox_Task8Name
            // 
            this.textBox_Task8Name.Location = new System.Drawing.Point(6, 18);
            this.textBox_Task8Name.Name = "textBox_Task8Name";
            this.textBox_Task8Name.Size = new System.Drawing.Size(120, 20);
            this.textBox_Task8Name.TabIndex = 16;
            this.textBox_Task8Name.TextChanged += new System.EventHandler(this.textBox_Task8Name_TextChanged);
            // 
            // numericUpDown_Task8Activation
            // 
            this.numericUpDown_Task8Activation.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_Task8Activation.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_Task8Activation.Name = "numericUpDown_Task8Activation";
            this.numericUpDown_Task8Activation.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task8Activation.TabIndex = 15;
            this.numericUpDown_Task8Activation.ValueChanged += new System.EventHandler(this.numericUpDown_Task8Activation_ValueChanged);
            // 
            // numericUpDown_Task8StackSize
            // 
            this.numericUpDown_Task8StackSize.Location = new System.Drawing.Point(6, 103);
            this.numericUpDown_Task8StackSize.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.numericUpDown_Task8StackSize.Name = "numericUpDown_Task8StackSize";
            this.numericUpDown_Task8StackSize.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Task8StackSize.TabIndex = 14;
            this.numericUpDown_Task8StackSize.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown_Task8StackSize.ValueChanged += new System.EventHandler(this.numericUpDown_Task8StackSize_ValueChanged);
            // 
            // checkBox_Task8Stack
            // 
            this.checkBox_Task8Stack.AutoSize = true;
            this.checkBox_Task8Stack.Location = new System.Drawing.Point(6, 67);
            this.checkBox_Task8Stack.Name = "checkBox_Task8Stack";
            this.checkBox_Task8Stack.Size = new System.Drawing.Size(90, 17);
            this.checkBox_Task8Stack.TabIndex = 13;
            this.checkBox_Task8Stack.Text = "Private Stack";
            this.checkBox_Task8Stack.UseVisualStyleBackColor = true;
            this.checkBox_Task8Stack.CheckedChanged += new System.EventHandler(this.checkBox_Task8Stack_CheckedChanged);
            // 
            // checkBox_Task8Auto
            // 
            this.checkBox_Task8Auto.AutoSize = true;
            this.checkBox_Task8Auto.Location = new System.Drawing.Point(6, 44);
            this.checkBox_Task8Auto.Name = "checkBox_Task8Auto";
            this.checkBox_Task8Auto.Size = new System.Drawing.Size(68, 17);
            this.checkBox_Task8Auto.TabIndex = 12;
            this.checkBox_Task8Auto.Text = "Autostart";
            this.checkBox_Task8Auto.UseVisualStyleBackColor = true;
            this.checkBox_Task8Auto.CheckedChanged += new System.EventHandler(this.checkBox_Task8Auto_CheckedChanged);
            // 
            // button_AddTask
            // 
            this.button_AddTask.Location = new System.Drawing.Point(333, 218);
            this.button_AddTask.Name = "button_AddTask";
            this.button_AddTask.Size = new System.Drawing.Size(56, 25);
            this.button_AddTask.TabIndex = 1;
            this.button_AddTask.Text = "Add";
            this.button_AddTask.UseVisualStyleBackColor = true;
            this.button_AddTask.Click += new System.EventHandler(this.button_AddTask_Click);
            // 
            // button_RemoveTask
            // 
            this.button_RemoveTask.Location = new System.Drawing.Point(395, 218);
            this.button_RemoveTask.Name = "button_RemoveTask";
            this.button_RemoveTask.Size = new System.Drawing.Size(56, 25);
            this.button_RemoveTask.TabIndex = 2;
            this.button_RemoveTask.Text = "Remove";
            this.button_RemoveTask.UseVisualStyleBackColor = true;
            this.button_RemoveTask.Click += new System.EventHandler(this.button_RemoveTask_Click);
            // 
            // ErikaOSTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.button_RemoveTask);
            this.Controls.Add(this.button_AddTask);
            this.Controls.Add(this.tabControl_Tasks);
            this.Name = "ErikaOSTask";
            this.Size = new System.Drawing.Size(462, 254);
            this.tabControl_Tasks.ResumeLayout(false);
            this.tabPage_Task1.ResumeLayout(false);
            this.tabPage_Task1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task1Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task1StackSize)).EndInit();
            this.tabPage_Task2.ResumeLayout(false);
            this.tabPage_Task2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task2Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task2StackSize)).EndInit();
            this.tabPage_Task3.ResumeLayout(false);
            this.tabPage_Task3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task3Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task3StackSize)).EndInit();
            this.tabPage_Task4.ResumeLayout(false);
            this.tabPage_Task4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task4Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task4StackSize)).EndInit();
            this.tabPage_Task5.ResumeLayout(false);
            this.tabPage_Task5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task5Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task5StackSize)).EndInit();
            this.tabPage_Task6.ResumeLayout(false);
            this.tabPage_Task6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task6Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task6StackSize)).EndInit();
            this.tabPage_Task7.ResumeLayout(false);
            this.tabPage_Task7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task7Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task7StackSize)).EndInit();
            this.tabPage_Task8.ResumeLayout(false);
            this.tabPage_Task8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task8Activation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Task8StackSize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_Tasks;
        private System.Windows.Forms.TabPage tabPage_Task1;
        private System.Windows.Forms.TabPage tabPage_Task2;
        private System.Windows.Forms.TabPage tabPage_Task3;
        private System.Windows.Forms.TabPage tabPage_Task4;
        private System.Windows.Forms.TabPage tabPage_Task5;
        private System.Windows.Forms.TabPage tabPage_Task6;
        private System.Windows.Forms.TabPage tabPage_Task7;
        private System.Windows.Forms.TabPage tabPage_Task8;
        private System.Windows.Forms.ComboBox comboBox_Task1Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task1Priority;
        private System.Windows.Forms.TextBox textBox_Task1Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task1Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task1StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task1Stack;
        private System.Windows.Forms.CheckBox checkBox_Task1Auto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox_Task2Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task2Priority;
        private System.Windows.Forms.TextBox textBox_Task2Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task2Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task2StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task2Stack;
        private System.Windows.Forms.CheckBox checkBox_Task2Auto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox_Task3Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task3Priority;
        private System.Windows.Forms.TextBox textBox_Task3Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task3Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task3StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task3Stack;
        private System.Windows.Forms.CheckBox checkBox_Task3Auto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox_Task4Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task4Priority;
        private System.Windows.Forms.TextBox textBox_Task4Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task4Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task4StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task4Stack;
        private System.Windows.Forms.CheckBox checkBox_Task4Auto;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox comboBox_Task5Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task5Priority;
        private System.Windows.Forms.TextBox textBox_Task5Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task5Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task5StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task5Stack;
        private System.Windows.Forms.CheckBox checkBox_Task5Auto;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBox_Task6Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task6Priority;
        private System.Windows.Forms.TextBox textBox_Task6Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task6Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task6StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task6Stack;
        private System.Windows.Forms.CheckBox checkBox_Task6Auto;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox comboBox_Task7Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task7Priority;
        private System.Windows.Forms.TextBox textBox_Task7Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task7Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task7StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task7Stack;
        private System.Windows.Forms.CheckBox checkBox_Task7Auto;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox comboBox_Task8Schedule;
        private System.Windows.Forms.ComboBox comboBox_Task8Priority;
        private System.Windows.Forms.TextBox textBox_Task8Name;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task8Activation;
        private System.Windows.Forms.NumericUpDown numericUpDown_Task8StackSize;
        private System.Windows.Forms.CheckBox checkBox_Task8Stack;
        private System.Windows.Forms.CheckBox checkBox_Task8Auto;
        private System.Windows.Forms.Button button_AddTask;
        private System.Windows.Forms.Button button_RemoveTask;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task1;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task2;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task3;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task4;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task5;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task6;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task7;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task8;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task1_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task2_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task3_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task4_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task5_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task6_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task7_Resource;
        private System.Windows.Forms.CheckedListBox checkedListBox_Task8_Resource;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
    }
}
